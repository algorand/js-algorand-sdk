
## Thanks

A big thank you to everyone who has contributed to the `go-algorand` codebase.

### External Contributors
In no particular order:
- zacharyestep
- jecassis
- mxmauro
- scnale
- jsign
- RomitKumar
- jeapostrophe

### Bug Reports
- Nanyan
- xixisese
