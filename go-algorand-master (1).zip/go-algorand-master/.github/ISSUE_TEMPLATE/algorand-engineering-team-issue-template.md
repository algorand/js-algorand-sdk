---
name: Algorand Engineering Team Issue Template
about: This is the template that Algorand internal team members use in conjunction
  with their task management process. Feel free to use if you're an external contributor.
title: ''
labels: ''
assignees: ''

---

## Summary
*Describe the problem identified or the general goal of this issue*

## Scope/Requirements
*What's involved in this issue? What's required to achieve the goal?*

## Urgency/Relative Priority
*How urgent is this issue? What are the timing considerations to take into account?*
