create table Service (
       data blob --*  msgpack encoding of Service
);
